﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPong
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPong))
        Me.lblLeft = New System.Windows.Forms.Label()
        Me.lblRight = New System.Windows.Forms.Label()
        Me.picLeft = New System.Windows.Forms.PictureBox()
        Me.picRight = New System.Windows.Forms.PictureBox()
        Me.timMovement = New System.Windows.Forms.Timer(Me.components)
        Me.picBall = New System.Windows.Forms.PictureBox()
        Me.cmdMulti = New System.Windows.Forms.Button()
        Me.cmdSingle = New System.Windows.Forms.Button()
        Me.cmdResume = New System.Windows.Forms.Button()
        Me.cmdNewGame = New System.Windows.Forms.Button()
        Me.trmAi = New System.Windows.Forms.Timer(Me.components)
        Me.picPause = New System.Windows.Forms.PictureBox()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.trmTime = New System.Windows.Forms.Timer(Me.components)
        Me.cmdEasy = New System.Windows.Forms.Button()
        Me.cmdNormal = New System.Windows.Forms.Button()
        Me.cmdHard = New System.Windows.Forms.Button()
        Me.cmd5min = New System.Windows.Forms.Button()
        Me.cmd2min = New System.Windows.Forms.Button()
        Me.cmd1min = New System.Windows.Forms.Button()
        Me.lblOptions = New System.Windows.Forms.Label()
        Me.lblDificulty = New System.Windows.Forms.Label()
        CType(Me.picLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBall, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPause, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblLeft
        '
        Me.lblLeft.AutoSize = True
        Me.lblLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLeft.ForeColor = System.Drawing.Color.White
        Me.lblLeft.Location = New System.Drawing.Point(152, 75)
        Me.lblLeft.Name = "lblLeft"
        Me.lblLeft.Size = New System.Drawing.Size(30, 31)
        Me.lblLeft.TabIndex = 0
        Me.lblLeft.Text = "0"
        '
        'lblRight
        '
        Me.lblRight.AutoSize = True
        Me.lblRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRight.ForeColor = System.Drawing.Color.White
        Me.lblRight.Location = New System.Drawing.Point(894, 75)
        Me.lblRight.Name = "lblRight"
        Me.lblRight.Size = New System.Drawing.Size(30, 31)
        Me.lblRight.TabIndex = 1
        Me.lblRight.Text = "0"
        '
        'picLeft
        '
        Me.picLeft.BackColor = System.Drawing.Color.White
        Me.picLeft.Location = New System.Drawing.Point(25, 308)
        Me.picLeft.Name = "picLeft"
        Me.picLeft.Size = New System.Drawing.Size(10, 100)
        Me.picLeft.TabIndex = 2
        Me.picLeft.TabStop = False
        '
        'picRight
        '
        Me.picRight.BackColor = System.Drawing.Color.White
        Me.picRight.Location = New System.Drawing.Point(1138, 308)
        Me.picRight.Name = "picRight"
        Me.picRight.Size = New System.Drawing.Size(10, 100)
        Me.picRight.TabIndex = 3
        Me.picRight.TabStop = False
        '
        'timMovement
        '
        Me.timMovement.Interval = 70
        '
        'picBall
        '
        Me.picBall.BackColor = System.Drawing.Color.White
        Me.picBall.Image = CType(resources.GetObject("picBall.Image"), System.Drawing.Image)
        Me.picBall.Location = New System.Drawing.Point(541, 358)
        Me.picBall.Name = "picBall"
        Me.picBall.Size = New System.Drawing.Size(26, 27)
        Me.picBall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBall.TabIndex = 4
        Me.picBall.TabStop = False
        '
        'cmdMulti
        '
        Me.cmdMulti.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmdMulti.ForeColor = System.Drawing.Color.White
        Me.cmdMulti.Location = New System.Drawing.Point(446, 529)
        Me.cmdMulti.Name = "cmdMulti"
        Me.cmdMulti.Size = New System.Drawing.Size(125, 59)
        Me.cmdMulti.TabIndex = 6
        Me.cmdMulti.Text = "Single PLayer"
        Me.cmdMulti.UseVisualStyleBackColor = False
        '
        'cmdSingle
        '
        Me.cmdSingle.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmdSingle.ForeColor = System.Drawing.Color.White
        Me.cmdSingle.Location = New System.Drawing.Point(590, 529)
        Me.cmdSingle.Name = "cmdSingle"
        Me.cmdSingle.Size = New System.Drawing.Size(123, 59)
        Me.cmdSingle.TabIndex = 7
        Me.cmdSingle.Text = "Multi PLayer"
        Me.cmdSingle.UseVisualStyleBackColor = False
        '
        'cmdResume
        '
        Me.cmdResume.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmdResume.ForeColor = System.Drawing.Color.White
        Me.cmdResume.Location = New System.Drawing.Point(448, 445)
        Me.cmdResume.Name = "cmdResume"
        Me.cmdResume.Size = New System.Drawing.Size(123, 59)
        Me.cmdResume.TabIndex = 9
        Me.cmdResume.Text = "Resume"
        Me.cmdResume.UseVisualStyleBackColor = False
        Me.cmdResume.Visible = False
        '
        'cmdNewGame
        '
        Me.cmdNewGame.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmdNewGame.ForeColor = System.Drawing.Color.White
        Me.cmdNewGame.Location = New System.Drawing.Point(590, 445)
        Me.cmdNewGame.Name = "cmdNewGame"
        Me.cmdNewGame.Size = New System.Drawing.Size(123, 59)
        Me.cmdNewGame.TabIndex = 10
        Me.cmdNewGame.Text = "New game"
        Me.cmdNewGame.UseVisualStyleBackColor = False
        Me.cmdNewGame.Visible = False
        '
        'trmAi
        '
        Me.trmAi.Interval = 30
        '
        'picPause
        '
        Me.picPause.Image = CType(resources.GetObject("picPause.Image"), System.Drawing.Image)
        Me.picPause.Location = New System.Drawing.Point(519, 14)
        Me.picPause.Name = "picPause"
        Me.picPause.Size = New System.Drawing.Size(100, 92)
        Me.picPause.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPause.TabIndex = 12
        Me.picPause.TabStop = False
        Me.picPause.Visible = False
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.ForeColor = System.Drawing.Color.White
        Me.lblTime.Location = New System.Drawing.Point(259, 75)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(134, 31)
        Me.lblTime.TabIndex = 13
        Me.lblTime.Text = "Time 2:00"
        '
        'trmTime
        '
        Me.trmTime.Interval = 1000
        '
        'cmdEasy
        '
        Me.cmdEasy.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmdEasy.ForeColor = System.Drawing.Color.White
        Me.cmdEasy.Location = New System.Drawing.Point(444, 182)
        Me.cmdEasy.Name = "cmdEasy"
        Me.cmdEasy.Size = New System.Drawing.Size(123, 59)
        Me.cmdEasy.TabIndex = 14
        Me.cmdEasy.Text = "Easy"
        Me.cmdEasy.UseVisualStyleBackColor = False
        Me.cmdEasy.Visible = False
        '
        'cmdNormal
        '
        Me.cmdNormal.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmdNormal.ForeColor = System.Drawing.Color.White
        Me.cmdNormal.Location = New System.Drawing.Point(444, 265)
        Me.cmdNormal.Name = "cmdNormal"
        Me.cmdNormal.Size = New System.Drawing.Size(123, 59)
        Me.cmdNormal.TabIndex = 15
        Me.cmdNormal.Text = "Normal"
        Me.cmdNormal.UseVisualStyleBackColor = False
        Me.cmdNormal.Visible = False
        '
        'cmdHard
        '
        Me.cmdHard.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmdHard.ForeColor = System.Drawing.Color.White
        Me.cmdHard.Location = New System.Drawing.Point(444, 349)
        Me.cmdHard.Name = "cmdHard"
        Me.cmdHard.Size = New System.Drawing.Size(123, 59)
        Me.cmdHard.TabIndex = 16
        Me.cmdHard.Text = "Extreme "
        Me.cmdHard.UseVisualStyleBackColor = False
        Me.cmdHard.Visible = False
        '
        'cmd5min
        '
        Me.cmd5min.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmd5min.ForeColor = System.Drawing.Color.White
        Me.cmd5min.Location = New System.Drawing.Point(590, 349)
        Me.cmd5min.Name = "cmd5min"
        Me.cmd5min.Size = New System.Drawing.Size(123, 59)
        Me.cmd5min.TabIndex = 19
        Me.cmd5min.Text = "5 minutes"
        Me.cmd5min.UseVisualStyleBackColor = False
        Me.cmd5min.Visible = False
        '
        'cmd2min
        '
        Me.cmd2min.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmd2min.ForeColor = System.Drawing.Color.White
        Me.cmd2min.Location = New System.Drawing.Point(590, 265)
        Me.cmd2min.Name = "cmd2min"
        Me.cmd2min.Size = New System.Drawing.Size(123, 59)
        Me.cmd2min.TabIndex = 18
        Me.cmd2min.Text = "2 minutes"
        Me.cmd2min.UseVisualStyleBackColor = False
        Me.cmd2min.Visible = False
        '
        'cmd1min
        '
        Me.cmd1min.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.cmd1min.ForeColor = System.Drawing.Color.White
        Me.cmd1min.Location = New System.Drawing.Point(590, 182)
        Me.cmd1min.Name = "cmd1min"
        Me.cmd1min.Size = New System.Drawing.Size(123, 59)
        Me.cmd1min.TabIndex = 17
        Me.cmd1min.Text = "1 minute"
        Me.cmd1min.UseVisualStyleBackColor = False
        Me.cmd1min.Visible = False
        '
        'lblOptions
        '
        Me.lblOptions.AutoSize = True
        Me.lblOptions.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOptions.ForeColor = System.Drawing.Color.White
        Me.lblOptions.Location = New System.Drawing.Point(457, 123)
        Me.lblOptions.Name = "lblOptions"
        Me.lblOptions.Size = New System.Drawing.Size(185, 31)
        Me.lblOptions.TabIndex = 20
        Me.lblOptions.Text = "Select options"
        '
        'lblDificulty
        '
        Me.lblDificulty.AutoSize = True
        Me.lblDificulty.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDificulty.ForeColor = System.Drawing.Color.White
        Me.lblDificulty.Location = New System.Drawing.Point(685, 75)
        Me.lblDificulty.Name = "lblDificulty"
        Me.lblDificulty.Size = New System.Drawing.Size(101, 31)
        Me.lblDificulty.TabIndex = 21
        Me.lblDificulty.Text = "Normal"
        '
        'frmPong
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(1184, 662)
        Me.Controls.Add(Me.cmdHard)
        Me.Controls.Add(Me.picBall)
        Me.Controls.Add(Me.lblOptions)
        Me.Controls.Add(Me.cmd5min)
        Me.Controls.Add(Me.cmd2min)
        Me.Controls.Add(Me.cmd1min)
        Me.Controls.Add(Me.cmdNormal)
        Me.Controls.Add(Me.cmdEasy)
        Me.Controls.Add(Me.cmdNewGame)
        Me.Controls.Add(Me.cmdResume)
        Me.Controls.Add(Me.cmdSingle)
        Me.Controls.Add(Me.cmdMulti)
        Me.Controls.Add(Me.picRight)
        Me.Controls.Add(Me.picLeft)
        Me.Controls.Add(Me.lblRight)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.lblLeft)
        Me.Controls.Add(Me.picPause)
        Me.Controls.Add(Me.lblDificulty)
        Me.Location = New System.Drawing.Point(541, 358)
        Me.Name = "frmPong"
        Me.Text = "Extreme VB Pong by Jrtechs.net"
        CType(Me.picLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBall, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPause, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblLeft As System.Windows.Forms.Label
    Friend WithEvents lblRight As System.Windows.Forms.Label
    Friend WithEvents picLeft As System.Windows.Forms.PictureBox
    Friend WithEvents picRight As System.Windows.Forms.PictureBox
    Friend WithEvents timMovement As System.Windows.Forms.Timer
    Friend WithEvents picBall As System.Windows.Forms.PictureBox
    Friend WithEvents cmdMulti As System.Windows.Forms.Button
    Friend WithEvents cmdSingle As System.Windows.Forms.Button
    Friend WithEvents cmdResume As System.Windows.Forms.Button
    Friend WithEvents cmdNewGame As System.Windows.Forms.Button
    Friend WithEvents trmAi As System.Windows.Forms.Timer
    Friend WithEvents picPause As System.Windows.Forms.PictureBox
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents trmTime As System.Windows.Forms.Timer
    Friend WithEvents cmdEasy As System.Windows.Forms.Button
    Friend WithEvents cmdNormal As System.Windows.Forms.Button
    Friend WithEvents cmdHard As System.Windows.Forms.Button
    Friend WithEvents cmd5min As System.Windows.Forms.Button
    Friend WithEvents cmd2min As System.Windows.Forms.Button
    Friend WithEvents cmd1min As System.Windows.Forms.Button
    Friend WithEvents lblOptions As System.Windows.Forms.Label
    Friend WithEvents lblDificulty As System.Windows.Forms.Label

End Class
