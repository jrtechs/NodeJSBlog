﻿Public Class frmPong
    'jeffery russell
    'vb pong
    '12-19-13
    Dim leftUp As Boolean
    Dim leftDown As Boolean
    Dim rightUp As Boolean
    Dim rightDown As Boolean
    Dim ballRise As Single = 0
    Dim ballRun As Single = -30
    Dim rightScore As Integer
    Dim leftScore As Integer
    Dim multi As Boolean = False
    Dim tsecs As Integer
    Dim tmin As Integer
    Dim optionsTim As Boolean = False
    Dim optionsDif As Boolean = False
    Dim lastmoveleft As String = "up"
    Dim lastmoveRight As String = "up"
    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyValue = Keys.Up Then
            rightUp = True
            rightDown = False
            lastmoveRight = "up"
        End If
        If e.KeyValue = Keys.Down Then
            rightUp = False
            rightDown = True
            lastmoveRight = "down"
        End If
        If e.KeyValue = Keys.Z Then
            leftDown = True
            leftUp = False
            lastmoveleft = "down"
        End If
        If e.KeyValue = Keys.A Then
            leftUp = True
            leftDown = False
            lastmoveleft = "up"
        End If
    End Sub

    Private Sub timMovement_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timMovement.Tick

        If leftUp = True Then
            picLeft.Location = New Point(picLeft.Location.X, picLeft.Location.Y - 30)
        End If
        If leftDown = True Then
            picLeft.Location = New Point(picLeft.Location.X, picLeft.Location.Y + 30)
        End If
        If rightUp = True Then
            picRight.Location = New Point(picRight.Location.X, picRight.Location.Y - 30)
        End If
        If rightDown = True Then
            picRight.Location = New Point(picRight.Location.X, picRight.Location.Y + 30)
        End If
        If picLeft.Top < 0 Then
            picLeft.Top += 30
        ElseIf picLeft.Top > 560 Then
            picLeft.Top -= 30
        End If
        If picRight.Top < 0 Then
            picRight.Top += 30
        ElseIf picRight.Top > 560 Then
            picRight.Top -= 30
        End If
        Dim randomRise As Integer
        Dim randomDirection As Integer
        Call Randomize()
        randomDirection = Int(Rnd() * (2 - 1 + 1)) + 1
        randomRise = Int(Rnd() * (20 - 1 + 1)) + 1
        picBall.Location = New Point(picBall.Location.X + ballRun, picBall.Location.Y + ballRise)
        If picBall.Bounds.IntersectsWith(picLeft.Bounds) Then
            'If leftUp = True Then
            '    ballRise = 20 + randomRise
            'ElseIf leftDown = True Then
            '    ballRise = -20 - randomRise

            'ElseIf randomDirection = 1 Then
            '    ballRise = -20 - randomRise
            'Else
            '    ballRise = 20 + randomRise
            'End If
            If lastmoveleft = "up" Then
                ballRise = -20 - randomRise
            Else
                ballRise = 20 + randomRise
            End If

            ballRun = 30

        ElseIf picBall.Bounds.IntersectsWith(picRight.Bounds) Then
            'If leftUp = True Then
            '    ballRise = -20 - randomRise
            'ElseIf leftDown = True Then
            '    ballRise = 20 + randomRise
            'ElseIf randomDirection = 1 Then
            '    ballRise = -20 - randomRise
            'Else
            '    ballRise = 20 + randomRise
            'End If
            If lastmoveRight = "up" Then
                ballRise = -20 - randomRise
            Else
                ballRise = 20 + randomRise
            End If
            ballRun = -30

        ElseIf picBall.Top < 0 Then
            ballRise = 20 + randomRise
        ElseIf picBall.Top > 630 Then
            ballRise = -20 - randomRise
        End If
        If picBall.Left < 0 Then
            rightScore += 1
            lblRight.Text = rightScore
            picBall.Location = New Point(541, 358)
            ballRun = -30
            ballRise = 0
        ElseIf picBall.Left > 1160 Then
            leftScore += 1
            lblLeft.Text = leftScore
            picBall.Location = New Point(541, 358)
            ballRun = 30
            ballRise = 0
        End If

    End Sub

    Private Sub frmPong_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        If e.KeyValue = Keys.A Then : leftUp = False : End If
        If e.KeyValue = Keys.Z Then : leftDown = False : End If
        If e.KeyValue = Keys.Up Then : rightUp = False : End If
        If e.KeyValue = Keys.Down Then : rightDown = False : End If
    End Sub


    Private Sub cmdMulti_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdMulti.Click
        multi = True
        optionVisiblet()
    End Sub

    Private Sub cmdSingle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSingle.Click
        multi = False
        optionVisiblet()
    End Sub
    Private Sub start()
        lblTime.Show()
        leftScore = 0
        rightScore = 0
        lblLeft.Text = leftScore
        lblRight.Text = rightScore
        fvisible()
        lblTime.Text = "Time " & tmin & ":00"
        If multi = True Then
            trmAi.Start()
            lblDificulty.Show()
        End If
        timMovement.Start()
        trmTime.Start()
        picPause.Visible = True
        Me.Focus()
    End Sub

    Private Sub cmdResume_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdResume.Click
        fvisible()
        picPause.Show()
        timMovement.Start()
        trmTime.Start()
        If multi = True Then
            trmAi.Start()
        End If
        Me.Focus()
    End Sub
    Private Sub fvisible()
        optionVisiblef()
       
        picPause.Visible = False
        cmdMulti.Visible = False
        cmdNewGame.Visible = False
        cmdResume.Visible = False
        cmdSingle.Visible = False
        Me.Focus()
    End Sub

    Private Sub cmdNewGame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNewGame.Click
        resetNew()
    End Sub
    Public Sub resetNew()
        fvisible()
        lblDificulty.Hide()
        lblTime.Visible = False
        optionsDif = False
        optionsTim = False
        tmin = 2
        tsecs = 0
        leftScore = 0
        rightScore = 0
        ballRise = 0
        ballRun = -30
        picBall.Location = New Point(541, 358)
        picLeft.Location = New Point(25, 308)
        picRight.Location = New Point(1138, 308)
        lblLeft.Text = leftScore
        lblRight.Text = rightScore
        cmdSingle.Visible = True
        cmdMulti.Visible = True
        Me.Focus()
        
    End Sub

    Private Sub trmAi_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trmAi.Tick
        If picLeft.Top + 50 < picBall.Top Then
            picLeft.Top += 15
        ElseIf picLeft.Top + 50 > picBall.Top Then
            picLeft.Top -= 15
        End If
    End Sub

    Private Sub picPause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picPause.Click
        timMovement.Stop()
        trmAi.Stop()
        trmTime.Stop()
        cmdNewGame.Visible = True
        cmdResume.Visible = True
        picPause.Visible = False
        Me.Focus()
    End Sub

    Private Sub trmTime_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trmTime.Tick
        If tmin <= 0 And tsecs <= 0 Then
            trmTime.Enabled = False
            trmAi.Stop()
            timMovement.Stop()
            If multi = True Then
                If leftScore > rightScore Then
                    MessageBox.Show("Times up the computer won", "End of round")
                    GoTo a
                ElseIf leftScore < rightScore Then
                    MessageBox.Show("Times up you have beaten the computer", "End of round")
                    GoTo a
                   

                End If
            End If
            If leftScore > rightScore Then
                MessageBox.Show("Times up the left player won", "End of round")
            ElseIf leftScore < rightScore Then
                MessageBox.Show("Times up the right player won", "End of round")
            End If
            If leftScore = rightScore Then
                Dim tieResult As MsgBoxResult
                tieResult = MessageBox.Show("There has been a tie would you like to take it into 30 sec overtime?", "Tie?", MessageBoxButtons.YesNo)
                If tieResult = MsgBoxResult.Yes Then
                    tsecs = 30
                    timMovement.Start()
                    trmTime.Start()
                    If multi = True Then
                        trmAi.Start()
                    End If
                    GoTo eend
                Else
                    MessageBox.Show("Nobody won because you did'nt play overtime", "Tie")
                End If

            End If
a:
            resetNew()
        End If
        If tsecs = 0 Then
            tmin -= 1
            tsecs = 59
        Else
            tsecs -= 1
        End If
        If tsecs < 10 Then
            lblTime.Text = "Time " & tmin & ":0" & tsecs
        Else
            lblTime.Text = "Time " & tmin & ":" & tsecs
        End If
eend:
    End Sub

    Private Sub frmPong_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        resetNew()
    End Sub
    Private Sub optionVisiblef()
        cmd1min.Hide()
        cmd2min.Hide()
        cmd5min.Hide()
        cmdEasy.Hide()
        cmdNormal.Hide()
        cmdHard.Hide()
        cmd1min.BackColor = Color.DarkGoldenrod
        cmd2min.BackColor = Color.DarkGoldenrod
        cmd5min.BackColor = Color.DarkGoldenrod
        cmdEasy.BackColor = Color.DarkGoldenrod
        cmdNormal.BackColor = Color.DarkGoldenrod
        cmdHard.BackColor = Color.DarkGoldenrod
        lblOptions.Hide()
    End Sub
    Private Sub optionVisiblet()
        cmdSingle.Hide()
        cmdMulti.Hide()
        cmd1min.Show()
        cmd2min.Show()
        cmd5min.Show()
        
        If multi = True Then
            cmdEasy.Show()
            cmdNormal.Show()
            cmdHard.Show()
        End If
        lblOptions.Show()
    End Sub

    Private Sub cmd1min_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd1min.Click
        cmd1min.BackColor = Color.Black
        cmd2min.BackColor = Color.DarkGoldenrod
        cmd5min.BackColor = Color.DarkGoldenrod
        tmin = 1
        tsecs = 0
        If multi = False Then
            start()
        End If
        optionsTim = True
        If optionsDif = True Then
            start()
        End If
    End Sub
    Private Sub cmd2min_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd2min.Click
        cmd1min.BackColor = Color.DarkGoldenrod
        cmd2min.BackColor = Color.Black
        cmd5min.BackColor = Color.DarkGoldenrod
        tmin = 2
        tsecs = 0
        If multi = False Then
            start()
        End If
        optionsTim = True
        If optionsDif = True Then
            start()
        End If
    End Sub
    Private Sub cmd5min_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd5min.Click
        cmd1min.BackColor = Color.DarkGoldenrod
        cmd2min.BackColor = Color.DarkGoldenrod
        cmd5min.BackColor = Color.Black
        tmin = 5
        tsecs = 0
        If multi = False Then
            start()
        End If
        optionsTim = True
        If optionsDif = True Then
            start()
        End If
    End Sub

    Private Sub cmdEasy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdEasy.Click
        lblDificulty.Text = "Easy"
        cmdEasy.BackColor = Color.Black
        cmdNormal.BackColor = Color.DarkGoldenrod
        cmdHard.BackColor = Color.DarkGoldenrod
        trmAi.Interval = 60
        optionsDif = True
        If optionsTim = True Then
            start()
        End If
    End Sub

    Private Sub cmdNormal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNormal.Click
        lblDificulty.Text = "Normal"
        cmdEasy.BackColor = Color.DarkGoldenrod
        cmdNormal.BackColor = Color.Black
        cmdHard.BackColor = Color.DarkGoldenrod
        trmAi.Interval = 45
        optionsDif = True
        If optionsTim = True Then
            start()
        End If
    End Sub

    Private Sub cmdHard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHard.Click
        lblDificulty.Text = "Extreme"
        cmdEasy.BackColor = Color.DarkGoldenrod
        cmdNormal.BackColor = Color.DarkGoldenrod
        cmdHard.BackColor = Color.Black
        trmAi.Interval = 30
        optionsDif = True
        If optionsTim = True Then
            start()
        End If
    End Sub
End Class
