
package zombiegame;

import java.awt.Color;
import java.awt.Graphics;


public class Bullet extends GameElement     
{
    private int direction; //0-up, 1-right, 2-down, 3-left
    private final int speed = 10;
    
    public Bullet(GameElement e)
    {
        super();
        height = 10;
        width = 10;
        direction = ((Player)(e)).facing;
        x = e.x;
        y = e.y;
    }
    
    public void render(Graphics g)
    {
        g.setColor(Color.BLACK);
        g.fillOval(x,y,width, height);
    }
    public boolean update(GameElement e)
    {
        //takes bullet off if goes out of bounds
        if(x < 0 || y < 0 || x > 700 || y > 700)
        {
            return true;
        }
        
        if(direction ==0)
        {
            y-=speed;
        }
        else if(direction == 1)
        {
            x+= speed;
        }
        else if(direction == 2)
        {
            y+= speed;
        }
        else
        {
            x-= speed;
        }
        
        
        return false;
    }
}
