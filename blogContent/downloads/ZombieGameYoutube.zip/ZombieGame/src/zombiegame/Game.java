package zombiegame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.Timer;

public class Game implements KeyListener
{
    public static Game game;
    private int kills;
    private int time;
    private int gameStatus;
    
    private ArrayList<GameElement> zombies;
    private ArrayList<GameElement> bullets;
    private GameElement player;
    
    public JFrame jframe;
    public Renderer renderer;
    
    Game()
    {
        jframe = new JFrame("Zombie Game");
        
        jframe.setSize(700, 700);
        jframe.setVisible(true);
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        renderer = new Renderer();
        jframe.add(renderer);
        jframe.addKeyListener(this);
        
        newGame();
        createTimers();
    }
    private void newGame()
    {
        kills = 0;
        time = 0; 
        zombies = new ArrayList<GameElement>();
        bullets = new ArrayList<GameElement>();
        player = new Player();
    }
    private void createTimers()
    {
        ActionListener moveTimer = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(gameStatus == 2)
                {
                    update();
                }
                renderer.repaint();
            }
        };
        Timer tp = new Timer(30, moveTimer);
        tp.start();
        ActionListener spawnTimer = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                if(gameStatus == 2)
                {
                    zombies.add(new Zombie());
                    time++;
                }
            }
        };
        Timer ts = new Timer(1000, spawnTimer);
        ts.start();
    }
    private void update()
    {
        player.update(null);
        for(int z = 0; z < zombies.size(); z++)
        {
            for(int b = 0; b < bullets.size(); b++)
            {
                if(zombies.get(z).checkCollision(bullets.get(b)))
                {
                    zombies.remove(z);
                    z--;
                    bullets.remove(b);
                    b--;
                    kills++;
                    break;
                }
            }
        }
        for(GameElement e : zombies)
            e.update(player);
        for(int b = 0; b < bullets.size(); b++)
        {
            if(bullets.get(b).update(null))
            {
                bullets.remove(b);
                b--;
            }
        }
        for(GameElement e : zombies)
        {
            if(e.checkCollision(player))
            {
                gameStatus = 1;
            }
        }
    }
    private void shoot()
    {
        bullets.add(new Bullet(player));
    }
    public void render(Graphics2D g)
    {
        if(gameStatus == 0)
        {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", 1, 50));
            
            g.drawString("Zombie Game", 250, 50);
            g.setFont(new Font("Arial", 1, 30));
            g.drawString("Press Space to Play", 250,325);
        }
        else if(gameStatus == 1)
        {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", 1, 50));
            
            g.drawString("Zombie Game", 250, 50);
            g.setFont(new Font("Arial", 1, 30));
            g.drawString("You survived for " + time + " seconds", 155,220);
            g.drawString("And killed " + kills +" Zombies", 180,275);
            
            g.drawString("Press C to play again", 200, 325);
            g.drawString("Press ESC for the Menu", 210, 375);
        }
        else if(gameStatus == 2)
        {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", 1, 30));
            
            g.drawString("Time: " + time,10,30);
            g.drawString("Kills: " + kills, 10, 60);
            
            this.player.render(g);
            
            for(GameElement e : bullets)
                e.render(g);
            for(GameElement e : zombies)
                e.render(g);
        }
        else
        {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", 1, 50));
            g.drawString("Paused", 250,325);
        }
    }
    
    public static void main(String[] arguments)
    {
        game = new Game();
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int id = e.getKeyCode();
        
        ((Player)(player)).updateDir(e, false);
        
        if(gameStatus == 3)
            gameStatus = 2;//resumes paused game
        if(id == KeyEvent.VK_SPACE)
        {
            if(gameStatus == 0)
            {
                newGame();
                gameStatus = 2;
            }
            else if(gameStatus == 2)
            {
                shoot();
            }
        }
        if(id == KeyEvent.VK_ESCAPE)
        {
            if(gameStatus == 1)
            {
                gameStatus = 0; //main
            }
            else if(gameStatus == 2)
            {
                gameStatus = 3; //pause
            }
        }
        if(id == KeyEvent.VK_C && gameStatus == 1)
        {
            newGame();
            gameStatus = 2;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        ((Player)(player)).updateDir(e, true);
    }
}
