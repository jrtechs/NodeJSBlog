package zombiegame;

import java.awt.Color;
import java.awt.Graphics;

public class Zombie extends GameElement
{
    private final int speed = 4;

    Zombie()
    {
        super();
        width = 25;
        height = 25;
        
        //places zombie on a random location along the game
        int side = (int)(Math.random() * 4) + 1;
        int mid = (int)(Math.random() * 700) + 1;
        if(side ==1)
        {
            x = mid;
            y = 0;
        }
        else if(side == 2)
        {
            x = 700;
            y = mid;
        }
        else if(side ==3)
        {
            y = 700;
            x = mid; 
        }
        else
        {
            x = 0;
            y = mid;
        }
    }
    
    public boolean update(GameElement e)
    {
        //vertical
        if(this.x > e.x + speed)
            this.x -= speed;
        else if(x + speed < e.x)
            this.x += speed;
        
        //horizontal
        if(this.y > e.y + speed)
            this.y -= speed;
        else if(y + speed < e.y)
            y+= speed;
        
        return false;
    }
    public void render(Graphics g)
    {
        g.setColor(Color.GREEN);
        g.fillRect(x, y, width, height);
    }
}
