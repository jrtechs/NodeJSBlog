/*
2-28-16
Jeffery Russell
Bullet class
*/
package Zombie;

import java.awt.Color;
import java.awt.Graphics;
/**
 *
 * @author jrtec
 */
public class Bullet extends GameElement
{
    private int direction; //0-up 1- right 2-down 3-left
    private final int speed = 10;
    
    
    public Bullet(GameElement e)
    {
        super();
        this.height = 10;
        this.width = 10;
        direction = ((Player)(e)).facing;
        this.x = e.x;
        this.y = e.y;
    }
    
    @Override
    public void render(Graphics g)
    {
        g.setColor(Color.BLACK);
        g.fillOval(x, y, width, height);
    }
    
    @Override
    public boolean update(GameElement e)
    {
        //checks to see if goes out of bounds
        if(x < 0 || y < 0 || x > 700 || y > 700)
        {
            return true;
        }
        //moves the bullet
        if(direction == 0)
        {
            y-= speed;
        }
        if(direction == 1)
        {
            x += speed;
        }
        if(direction == 2)
        {
            y += speed;
        }
        if(direction == 3)
        {
            x -= speed;
        }
        
        return false;
    }
    
}
