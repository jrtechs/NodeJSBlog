/*
Jeffery Russell
2-27-16
*/
package Zombie;

import java.util.ArrayList;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.Timer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public class Game implements KeyListener
{
    public static Game game;
    
    private int width = 700, height = 700;
    private int kills;
    private int time;
    private ArrayList<GameElement> zombies;
    private ArrayList<GameElement> bullets;
    private GameElement player;
    
    public JFrame jframe;
    
    public Renderer renderer;
    
    private int gameStatus;

    Game()
    {
        jframe = new JFrame("Zombie Game by Jeffery Russell");
        renderer = new Renderer();
        
        jframe.setSize(width, height);
        jframe.setVisible(true);
	jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        
        jframe.add(renderer);
        jframe.addKeyListener(this);

        newGame();
        createTimers();
    }
    public void newGame()
    {
        kills = 0;
        time = 0;
        zombies = new ArrayList<GameElement>();
        bullets = new ArrayList<GameElement>();
        player = new Player();
    }
    public void createTimers()
    {
         ActionListener moveTimer = new ActionListener()
        { 
            public void actionPerformed(ActionEvent e)
            {
                if(gameStatus == 2)
                    update();
                renderer.repaint();  
            }
        };
        Timer tP = new Timer(30, moveTimer);
        tP.start();
        ActionListener spawnTimer = new ActionListener()
        { 
            public void actionPerformed(ActionEvent e)
            {
                if(gameStatus == 2)
                {
                   zombies.add(new Zombie());
                   time++; 
                }
            }
        };
        Timer tS = new Timer(1000, spawnTimer);
        tS.start();
    }
    public void update()
    {
        player.update(null);
        for(int z = 0; z < zombies.size(); z ++)
        {
            for(int b = 0; b < bullets.size(); b ++)
            {
                if(zombies.get(z).checkCollision(bullets.get(b)))
                {
                    zombies.remove(z);
                    z--;
                    bullets.remove(b);
                    b--;
                    kills++;
                    break;
                }
            }
        }
        for(GameElement e : zombies)
            e.update(player);  
        for(int b = 0; b < bullets.size(); b++)
        {
            if(bullets.get(b).update(null))
            {
                bullets.remove(b);
                b--;
            }
        }
        for(GameElement e : zombies)
            if(e.checkCollision(player))
            {
                gameStatus = 1;
            }
    }
    private void shoot()
    {
        bullets.add(new Bullet(player));
    }
    public void render(Graphics2D g)
    {
        if (gameStatus == 0)
        {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", 1, 50));

            g.drawString("Zombie Game", width / 2 - 150, 50);

            g.setFont(new Font("Arial", 1, 30));

            g.drawString("Press Space to Play", width / 2 - 150, height / 2 - 25); 
        }
        else if(gameStatus == 2)
        {
            g.setFont(new Font("Arial", 1, 30));
            g.drawString("Time: " + time, 10, 30);
            g.drawString("Kills: " + kills, 10, 60);
            this.player.render(g);
            for(GameElement e : this.bullets)
                e.render(g);
            for(GameElement e : this.zombies)
                e.render(g);
        }
        else if(gameStatus == 1)
        {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", 1, 50));

            g.drawString("Zombie Game", width / 2 - 150, 50);

            g.setFont(new Font("Arial", 1, 30));
            g.drawString("You Survived for " + this.time + " seconds", width / 2 - 195, 220);
            g.drawString("And killed " + kills + " Zombies!", width / 2 - 170, 275);


            g.setFont(new Font("Arial", 1, 30));

            g.drawString("Press C to Play Again", width / 2 - 150, height / 2 - 25);
            g.drawString("Press ESC for Menu", width / 2 - 140, height / 2 + 25);
        }
        else //3
        {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", 1, 50));
            g.drawString("PAUSED", width / 2 - 103, height / 2 - 25);
        }
    }
    @Override
    public void keyTyped(KeyEvent e) 
    {
    }
    @Override
    public void keyPressed(KeyEvent e) 
    {
        int id = e.getKeyCode();
        
        ((Player)(player)).updateDir(e, false);
        
         if(gameStatus == 3)
            gameStatus =2;//resume game
        if (id == KeyEvent.VK_SPACE)
        {
            if(this.gameStatus == 0)
            {
                newGame();
                gameStatus = 2;
            }   
            else if(gameStatus == 2)
                shoot();
        }
        if(id == KeyEvent.VK_ESCAPE)
        {
            if(gameStatus == 1)
                gameStatus = 0; //main menu
            else if(gameStatus == 2)
                gameStatus = 3; //pause
        }
        if (id == KeyEvent.VK_C && gameStatus == 1)
        {
            newGame();
            gameStatus = 2;
            
        }
    }
    @Override
    public void keyReleased(KeyEvent e) 
    {
        ((Player)(player)).updateDir(e, true);
    }
    public static void main(String[] arguments)
    {
        game = new Game();
    }
}
