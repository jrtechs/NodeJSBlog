/*
Jeffery Russell
2-28-16
Player game object
*/
package Zombie;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;

public class Player extends GameElement
{
    private final int speed = 5;
    
    public boolean upB, downB, leftB, rightB;
    
    public int facing; //0-up 1- right 2-down 3-left
    
    public Player()
    {
        super();
        this.x = 350;
        this.y = 350;
        this.width = 25;
        this.height = 25;
    }
    
    @Override
    public boolean update(GameElement e) 
    {
        if(upB)
            this.y -= speed;
        if(downB)
            this.y += speed;
        if(leftB)
            this.x -= speed;
        if(rightB)
            this.x += speed;
        
        return false;
    }

    @Override
    public void render(Graphics g) 
    {
        g.setColor(Color.BLUE);
        g.fillRect(x, y, width, height);
    }
    
    public void updateDir(KeyEvent e, boolean d)
    {
        //d -- false(pressed)  true(relesed)
        int id = e.getKeyCode();
        if (id == KeyEvent.VK_W || id == KeyEvent.VK_UP)
        {
            if(d)
            {
                upB = false;
            }
            else
            {
                upB = true;
                facing = 0;
            }
        }
        else if (id == KeyEvent.VK_S || id == KeyEvent.VK_DOWN)
        {
            if(d)
            {
                downB = false;
            }
            else
            {
                downB = true;
                facing = 2;
            }
        }
        else if (id == KeyEvent.VK_A || id == KeyEvent.VK_LEFT)
        {
            if(d)
            {
                leftB = false;
            }
            else
            {
                leftB = true;
                facing = 3;
            }
        }
        else if (id == KeyEvent.VK_D || id == KeyEvent.VK_RIGHT)
        {
            if(d)
            {
                rightB = false;
            }
            else
            {
                rightB = true;
                facing = 1;
            }
        }
    }
}
