﻿Public Class frmZombieGame
    Dim upb As Boolean
    Dim downb As Boolean = False
    Dim leftb As Boolean = False
    Dim rightb As Boolean = False
    Dim shootUpb As Boolean = False
    Dim shootDownnb As Boolean = False
    Dim shootLeftb As Boolean = False
    Dim shootRightb As Boolean = False


    Dim minutes As Integer = 0
    Dim seconds As Integer = 0
    Dim tempCount As Integer = 0

    Dim bullet(50) As PictureBox
    Dim bulletUse(50) As Boolean
    Dim bulletDirection(50) As Integer

    Dim zombieSpawn As Integer = 0
    Dim zombie(50) As PictureBox
    Dim zombieUse(50) As Boolean

    Dim health As Integer
    Dim kills As Integer = 0
    Private Sub trmMovement_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trmMovement.Tick
        'moves player
        If upb = True Then
            picPlayer.Location = New Point(picPlayer.Location.X, picPlayer.Location.Y - 15)
        End If
        If downb = True Then
            picPlayer.Location = New Point(picPlayer.Location.X, picPlayer.Location.Y + 15)
        End If
        If leftb = True Then
            picPlayer.Location = New Point(picPlayer.Location.X - 15, picPlayer.Location.Y)
        End If
        If rightb = True Then
            picPlayer.Location = New Point(picPlayer.Location.X + 15, picPlayer.Location.Y)
        End If
        'moves bullets
        For i = 0 To 49 Step 1
            If bulletUse(i) = True Then
                If bulletDirection(i) = 1 Then
                    'up
                    bullet(i).Location = New Point(bullet(i).Location.X, bullet(i).Location.Y - 20)
                ElseIf bulletDirection(i) = 2 Then
                    'down
                    bullet(i).Location = New Point(bullet(i).Location.X, bullet(i).Location.Y + 20)
                ElseIf bulletDirection(i) = 3 Then
                    'left
                    bullet(i).Location = New Point(bullet(i).Location.X - 20, bullet(i).Location.Y)
                Else
                    'right
                    bullet(i).Location = New Point(bullet(i).Location.X + 20, bullet(i).Location.Y)
                End If
                'collisions wit zombies
                For y = 0 To 49 Step 1
                    If zombieUse(y) = True Then
                        If zombie(y).Bounds.IntersectsWith(bullet(i).Bounds) Then
                            Me.Controls.Remove(bullet(i))
                            Me.Controls.Remove(zombie(y))
                            bulletUse(i) = False
                            zombieUse(y) = False
                            kills += 1
                            lblKills.Text = "Kills: " & kills
                        End If
                    End If
                Next
            End If


        Next
        'zombie spawn
        zombieSpawn += 1

        If zombieSpawn = 15 Then
            Dim avalible As Integer = 0
            zombieSpawn = 0
            For i = 0 To 49 Step 1
                If zombieUse(i) = False Then
                    avalible = i
                    GoTo a
                End If
            Next
a:
            zombie(avalible) = New PictureBox
            zombie(avalible).Width = 50
            zombie(avalible).Height = 50
            zombie(avalible).Image = picZombiePic.Image
            zombie(avalible).BackColor = Color.Transparent
            zombieUse(avalible) = True
            Call Randomize()
            Dim randomSide As Integer
            randomSide = Int(Rnd() * (4)) + 1
            Dim randomLocation As Integer
            randomLocation = Int(Rnd() * (600)) + 1
            If randomSide = 1 Then
                'top
                zombie(avalible).Location = New Point(randomLocation, 20)
            ElseIf randomSide = 2 Then
                'bottom
                zombie(avalible).Location = New Point(randomLocation, 580)
            ElseIf randomSide = 3 Then
                'left
                zombie(avalible).Location = New Point(20, randomLocation)
            Else
                'right
                zombie(avalible).Location = New Point(680, randomLocation)
            End If
            Me.Controls.Add(zombie(avalible))
        End If
        'move zombies
        For i = 0 To 49 Step 1
            If zombieUse(i) = True Then
                If picPlayer.Left > zombie(i).Left - 10 Then
                    'move right
                    zombie(i).Location = New Point(zombie(i).Location.X + 10, zombie(i).Location.Y)
                ElseIf picPlayer.Left < zombie(i).Left + 10 Then
                    'move left
                    zombie(i).Location = New Point(zombie(i).Location.X - 10, zombie(i).Location.Y)
                End If
                If picPlayer.Top > zombie(i).Top - 10 Then
                    'move down
                    zombie(i).Location = New Point(zombie(i).Location.X, zombie(i).Location.Y + 10)
                ElseIf picPlayer.Top < zombie(i).Top + 10 Then
                    'move up
                    zombie(i).Location = New Point(zombie(i).Location.X, zombie(i).Location.Y - 10)
                End If
                If zombie(i).Bounds.IntersectsWith(picPlayer.Bounds) Then
                    health -= 5
                    lblHealth.Text = "Health: " & health
                    If health <= 0 Then
                        trmMovement.Stop()
                        MessageBox.Show("You have died")
                    End If
                End If
            End If
        Next
        'timmer
        tempCount += 1
        If tempCount = 10 Then
            tempCount = 0
            seconds += 1
            If seconds = 60 Then
                seconds = 0
                minutes += 1
            End If
            If seconds >= 10 Then
                lblTime.Text = "Time: " & minutes & ":" & seconds
            Else
                lblTime.Text = "Time: " & minutes & ":" & "0" & seconds
            End If

        End If
    End Sub

    Private Sub frmZombieGame_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Down Then
            downb = True
            shootDownnb = True
            shootLeftb = False
            shootRightb = False
            shootUpb = False
        ElseIf e.KeyCode = Keys.Up Then
            upb = True
            shootDownnb = False
            shootLeftb = False
            shootRightb = False
            shootUpb = True
        ElseIf e.KeyCode = Keys.Left Then
            leftb = True
            shootDownnb = False
            shootLeftb = True
            shootRightb = False
            shootUpb = False
        ElseIf e.KeyCode = Keys.Right Then
            rightb = True
            shootDownnb = False
            shootLeftb = False
            shootRightb = True
            shootUpb = False
        End If
        'shoot
        If e.KeyCode = Keys.Space Then
            Dim avalible As Integer
            For i = 0 To 49 Step 1
                'finds a container in the array thats not in use
                If bulletUse(i) = False Then
                    avalible = i
                    GoTo b
                End If
            Next
b:
            'direction of bullet
            If shootDownnb = True Then
                bulletDirection(avalible) = 2
            ElseIf shootUpb = True Then
                bulletDirection(avalible) = 1
            ElseIf shootLeftb = True Then
                bulletDirection(avalible) = 3
            Else
                bulletDirection(avalible) = 4
            End If
            'creates a new dynamic bullet box
            bullet(avalible) = New PictureBox
            bullet(avalible).Image = picBulletPic.Image
            bullet(avalible).Width = 20
            bullet(avalible).Height = 20
            bullet(avalible).Location = New Point(picPlayer.Location.X, picPlayer.Location.Y)
            Me.Controls.Add(bullet(avalible))
            bulletUse(avalible) = True
        End If

    End Sub

    Private Sub frmZombieGame_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Down Then
            downb = False
        ElseIf e.KeyCode = Keys.Up Then
            upb = False
        ElseIf e.KeyCode = Keys.Left Then
            leftb = False
        ElseIf e.KeyCode = Keys.Right Then
            rightb = False
        End If
    End Sub

    Private Sub PlayToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlayToolStripMenuItem.Click
        trmMovement.Start()

    End Sub

    Private Sub PauseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PauseToolStripMenuItem.Click
        trmMovement.Stop()

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub

    Private Sub NewGameToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewGameToolStripMenuItem.Click
        On Error Resume Next
        For i = 0 To 49 Step 1
            Me.Controls.Remove(zombie(i))
            Me.Controls.Remove(bullet(i))
            bulletUse(i) = False
            zombieUse(i) = False
            lblHealth.Text = "Health: 100"
            health = 100
            kills = 0
            lblKills.Text = "Kills: 0"
            lblTime.Text = "Time: 0:00"
            tempCount = 0
            minutes = 0
            seconds = 0
            upb = False
            downb = False
            leftb = False
            rightb = False

        Next
    End Sub
End Class
