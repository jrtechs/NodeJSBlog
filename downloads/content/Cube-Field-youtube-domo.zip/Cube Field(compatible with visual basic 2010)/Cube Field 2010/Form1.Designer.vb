﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.picPlayer = New System.Windows.Forms.PictureBox()
        Me.cmdPlay = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.spawn = New System.Windows.Forms.Timer(Me.components)
        Me.trmTime = New System.Windows.Forms.Timer(Me.components)
        CType(Me.picPlayer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.Location = New System.Drawing.Point(368, 28)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(67, 31)
        Me.lblTime.TabIndex = 5
        Me.lblTime.Text = "0:00"
        '
        'picPlayer
        '
        Me.picPlayer.BackColor = System.Drawing.Color.MediumTurquoise
        Me.picPlayer.Location = New System.Drawing.Point(196, 519)
        Me.picPlayer.Name = "picPlayer"
        Me.picPlayer.Size = New System.Drawing.Size(57, 61)
        Me.picPlayer.TabIndex = 4
        Me.picPlayer.TabStop = False
        '
        'cmdPlay
        '
        Me.cmdPlay.BackColor = System.Drawing.Color.Silver
        Me.cmdPlay.Location = New System.Drawing.Point(185, 102)
        Me.cmdPlay.Name = "cmdPlay"
        Me.cmdPlay.Size = New System.Drawing.Size(121, 75)
        Me.cmdPlay.TabIndex = 3
        Me.cmdPlay.Text = "Play"
        Me.cmdPlay.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        '
        'spawn
        '
        Me.spawn.Interval = 500
        '
        'trmTime
        '
        Me.trmTime.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(468, 592)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.picPlayer)
        Me.Controls.Add(Me.cmdPlay)
        Me.Name = "Form1"
        Me.Text = "Cube Field by jrtechs"
        CType(Me.picPlayer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents picPlayer As System.Windows.Forms.PictureBox
    Friend WithEvents cmdPlay As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents spawn As System.Windows.Forms.Timer
    Friend WithEvents trmTime As System.Windows.Forms.Timer

End Class
