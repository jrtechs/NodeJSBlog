﻿Public Class Form1
    Dim leftb As Boolean = False
    Dim rightb As Boolean = False
    Dim enemyUse(50) As Boolean
    Dim enemy(50) As PictureBox
    Dim minutes As Integer = 0
    Dim seconds As Integer = 0
    Private Sub cmdPlay_Click(sender As Object, e As EventArgs) Handles cmdPlay.Click
        Timer1.Start()
        trmTime.Start()
        spawn.Start()
        cmdPlay.Hide()
        Me.Focus()
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Left Then
            leftb = True
        ElseIf e.KeyCode = Keys.Right Then
            rightb = True
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Left Then
            leftb = False
        ElseIf e.KeyCode = Keys.Right Then
            rightb = False
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If leftb = True Then
            picPlayer.Left -= 20
        End If
        If rightb = True Then
            picPlayer.Left += 20
        End If
        If picPlayer.Left < 0 Then
            picPlayer.Left += 25
        ElseIf picPlayer.Left > Me.Width Then
            picPlayer.Left -= 25
        End If
        For i = 0 To 49 Step 1
            If enemyUse(i) = True Then
                enemy(i).Top += 20
                If enemy(i).Top > Me.Height Then
                    enemy(i).Hide()
                    enemyUse(i) = False
                End If
                If enemy(i).Bounds.IntersectsWith(picPlayer.Bounds) Then
                    trmTime.Stop()
                    spawn.Stop()
                    Timer1.Stop()
                    MessageBox.Show("You have died")
                    For y = 0 To 49 Step 1
                        If enemyUse(y) = True Then
                            enemyUse(y) = False
                            enemy(y).Hide()
                            minutes = 0
                            seconds = 0
                            lblTime.Text = "0:00"
                            cmdPlay.Show()
                        End If
                    Next
                End If
            End If

        Next

    End Sub

    Private Sub spawn_Tick(sender As Object, e As EventArgs) Handles spawn.Tick
        Dim avalible As Integer = 0
        For i = 0 To 49 Step 1
            If enemyUse(i) = False Then
                avalible = i
                GoTo a
            End If
        Next
a:
        enemy(avalible) = New PictureBox
        enemy(avalible).Size = New Size(30, 30)
        enemy(avalible).BackColor = Color.Black
        Dim RandomLocation As Integer
        Call Randomize()
        RandomLocation = Int(Rnd() * (Me.Width))
        enemy(avalible).Location = New Point(RandomLocation, 0)
        enemy(avalible).Visible = True
        enemyUse(avalible) = True
        Me.Controls.Add(enemy(avalible))
    End Sub

    Private Sub trmTime_Tick(sender As Object, e As EventArgs) Handles trmTime.Tick
        seconds += 1
        If seconds = 60 Then
            minutes += 1
        End If
        If seconds = 0 Then
            lblTime.Text = minutes & ":00"
        ElseIf seconds >= 10 Then
            lblTime.Text = minutes & ":" & seconds
        Else
            lblTime.Text = minutes & ":0" & seconds
        End If
    End Sub
End Class
